# Game Results System

---

## Purpose
Define the enforceable, lossless, and explicit rules, constraints, workflows, and definitions for the Game Results system, as migrated from all planning sources.

---

## Definitions
- **Game Results:** The system for communicating game outcomes, statistics, and rewards to players.
- **Post-Game Actions:** Options available to players after a game, such as replay, share, or continue.
- **Progression Integration:** Automatic update of XP, achievements, and event progress based on results.

---

## Core Concepts
- All game outcomes are communicated clearly and immediately after each session.
- Statistics, rewards, and progression updates are surfaced in a unified interface.
- Post-game actions are accessible and encourage continued engagement.
- Results integrate with achievements, progression, and events.

---

## Rules
- IF a game session ends, THEN the system MUST display outcome, statistics, and rewards to all players.
- IF a player earns an achievement or progression milestone, THEN it MUST be surfaced in the results interface.
- IF post-game actions are available, THEN they MUST be accessible and clearly labeled.

---

## Constraints
- MUST NOT delay or obscure outcome and reward information.
- MUST ensure all statistics and rewards are accurate and auditable.
- MUST integrate with progression, achievements, and event systems.

---

## Workflows
### Workflow: Display Game Results
1. Game session ends.
2. System calculates outcome, statistics, and rewards.
3. Results interface displays all information to players.
4. Progression, achievements, and events are updated.

### Workflow: Post-Game Actions
1. Player reviews results.
2. Player selects post-game action (replay, share, continue, etc.).
3. System processes action and transitions player as needed.

---

## Edge Cases
- Scenario: Discrepancy in statistics or rewards → System logs and flags for review.
- Scenario: Player disconnects before results → System stores and displays on next login.

---

## System Interfaces
- Interacts with: Progression, Achievements, Events, Social, Tools.

---

## Notes
- All rules, constraints, and workflows are traceable to original planning docs.

---

## Source References
- Derived from: GAME_RESULTS_SYSTEM.md, game pillar docs, core doctrine, security standards.

---

**Migrated and merged content. All conflicts resolved per doctrine.**