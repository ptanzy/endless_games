# EndlessVault System

---

## Purpose
Define the EndlessVault seasonal token bank where players lock EndlessCoin for bonus rewards.

---

## Goals
- Reward long-term commitment
- Provide seasonal bonuses
- Encourage retention
- Maintain cosmetic-only rules

---

## Personas
- **Player:** Wants bonus rewards
- **Clan Leader:** Wants clan vault bonuses
- **Platform Operator:** Wants predictable engagement

---

## User Stories
- As a player, I want to lock tokens for seasonal bonuses.
- As a player, I want to choose how long to lock.

---

## Core Capabilities
- Token locking
- Bonus multipliers
- Seasonal rewards
- Vault tiers

---

## Workflows
### Workflow: Locking
1. Player selects amount
2. Selects duration
3. Vault locks
4. Rewards delivered at season end

---

## Rules & Constraints
- No early withdrawal
- Cosmetic-only rewards
- No gambling mechanics

---

## Deep Dive
### Vault Tiers
- Bronze
- Silver
- Gold
- Prestige

### Bonus Types
- Cosmetics
- EndlessCoin multipliers
- Seasonal badges

---

## Notes
- All rules, constraints, and workflows are traceable to original planning docs.

---

## Source References
- Migrated and merged from: ENDLESSVAULT_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**