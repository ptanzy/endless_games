
# Affiliate System

---

## Purpose
Define the affiliate system (EndlessDeals) that rewards players and creators for completing partner offers, generating impressions, and driving purchases—safely and transparently.

---

## Definitions
- **Affiliate Offer:** Partner-provided task (survey, install, purchase, trial).
- **Impression Tracking:** Logging of offer views and completions.
- **Creator Attribution:** Revenue share for creators driving conversions.

---

## Core Concepts
- All offers are manually reviewed for safety.
- No predatory, unsafe, or dark pattern offers.
- Clear time/value disclosure for all offers.
- Affiliate revenue is shared with creators per deterministic rules.

---

## Rules
- IF a player completes an affiliate offer, THEN the system MUST validate the offer and reward EndlessCoin.
- IF a viewer completes an offer via creator content, THEN the system MUST track conversion and reward the creator.
- IF an offer is flagged as unsafe, THEN the system MUST block and log the event.

---

## Constraints
- MUST NOT allow adult content, gambling, or crypto scams.
- MUST NOT allow unsafe or exploitative offers.
- MUST ensure all attribution and reward logic is auditable.
- MUST review and approve all offers for safety and compliance.

---

## Workflows
### Player Offer Completion
1. Player selects offer.
2. Completes task.
3. Partner confirms.
4. Player receives EndlessCoin.

### Creator Affiliate Attribution
1. Viewer clicks offer from creator content.
2. Conversion tracked.
3. Creator receives share.

---

## Edge Cases
- Scenario: Offer flagged as unsafe → System blocks and logs event.
- Scenario: Attempted fraud or duplicate completion → System denies reward.
- Scenario: Partner fails to confirm completion → No reward granted.

---

## System Interfaces
- Interacts with: Offerwall, EndlessDeals, Creator Ecosystem, Partner Offer Data, Security, Tools.

---

## Notes
- All affiliate logic, rules, and constraints are losslessly migrated from AFFILIATE_SYSTEM_PLANNING.md and related docs.
- All conflicts resolved per doctrine; all rules are explicit and enforceable.

---

## Source References
- /planning/economy/AFFILIATE_SYSTEM_PLANNING.md