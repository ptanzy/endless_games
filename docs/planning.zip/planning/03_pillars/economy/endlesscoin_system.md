# EndlessCoin System

---

## Purpose
Define the enforceable, lossless, and explicit rules, constraints, workflows, and definitions for the EndlessCoin soft-currency system, as migrated from all planning sources.

---

## Definitions
- **EndlessCoin:** Primary soft-currency earned through gameplay, ads, affiliate actions, and platform engagement. Used for progression and cosmetic-only purchases.
- **Earn Cap:** Daily/weekly maximums for EndlessCoin earnings.
- **Anti-Abuse Detection:** Systemic checks to prevent exploitative earning.

---

## Core Concepts
- EndlessCoin is earned, not purchased.
- All earn and spend actions are validated for fairness and compliance.
- No pay-to-win or gameplay advantage can be purchased with EndlessCoin.
- Earn caps and anti-abuse logic are enforced platform-wide.

---

## Rules
- IF a player completes an eligible action, THEN the system MUST calculate and award EndlessCoin.
- IF a player exceeds the earn cap, THEN the system MUST block further earnings until reset.
- IF suspicious earning patterns are detected, THEN the system MUST flag and review the account.
- IF EndlessCoin is spent, THEN the system MUST validate the purchase and deduct the correct amount.

---

## Constraints
- MUST NOT allow EndlessCoin to be purchased directly.
- MUST NOT allow EndlessCoin to be used for pay-to-win or gameplay advantage.
- MUST enforce daily/weekly earn caps.
- MUST review and flag suspicious earning or spending patterns.

---

## Workflows
### Workflow: Earn EndlessCoin
1. Player completes eligible action (gameplay, ad, affiliate, event).
2. System checks earn rules and caps.
3. Earn amount calculated and awarded.
4. Anti-abuse filters applied.
5. EndlessCoin added to wallet.

### Workflow: Spend EndlessCoin
1. Player selects cosmetic or deal.
2. System checks balance and eligibility.
3. Purchase validated and EndlessCoin deducted.
4. Item delivered to player.

---

## Edge Cases
- Scenario: Attempted exploit of earn system → System blocks, logs, and flags account.
- Scenario: Attempted purchase of gameplay advantage → System denies and notifies user.

---

## System Interfaces
- Interacts with: Progression, Events, Social, Economy, Security, Tools.

---

## Notes
- All rules, constraints, and workflows are traceable to original planning docs.

---

## Source References
- Derived from: ENDLESSCOIN_SYSTEM_PLANNING.md, economy pillar docs, core doctrine, security standards.

---

**Migrated and merged content. All conflicts resolved per doctrine.**