# Social Economy System

---

## Purpose
Define the social-driven economic systems that reward players for clan participation, social engagement, and preset-only interactions.

---

## Goals
- Reward social participation
- Strengthen clans
- Support preset-only interactions
- Maintain zero-moderation safety

---

## Personas
- **Player:** Wants social rewards
- **Clan Leader:** Wants clan progression
- **Creator:** Wants social boosts

---

## User Stories
- As a player, I want rewards for clan events.
- As a clan leader, I want clan treasury earnings.
- As a player, I want preset-only social bonuses.

---

## Core Capabilities
- Clan rewards
- Clan treasury
- Social engagement bonuses
- Seasonal clan events

---

## Workflows
### Workflow: Clan Event Rewards
1. Clan participates
2. Event ends
3. Rewards distributed

---

## Rules & Constraints
- Preset-only communication
- No unsafe social channels
- No pay-to-win clan bonuses

---

## Deep Dive
### Clan Treasury
- Earn EndlessGold
- From clan ads
- From clan events

### Social Bonuses
- Preset reactions
- Preset comments
- Seasonal social events

---

## Notes
- All rules, constraints, and workflows are traceable to original planning docs.

---

## Source References
- Migrated and merged from: SOCIAL_ECONOMY_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**