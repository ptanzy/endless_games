# EndlessDeals System

---

## Purpose
Define EndlessDeals, the rotating offer system that provides players with daily, weekly, and seasonal cosmetic deals using EndlessCoin or EndlessGold—always cosmetic-only, never pay-to-win, and always player-first.

---

## Goals
- Provide exciting rotating cosmetic offers
- Reward active players with better deals
- Maintain fairness and transparency
- Integrate with EndlessCoin, EndlessGold, and EndlessPass

---

## Personas
- **Player:** Wants fun, rotating cosmetic deals
- **Collector:** Wants rare or seasonal cosmetics
- **Platform:** Needs predictable rotation rules

---

## User Stories
- As a player, I want daily deals that feel rewarding.
- As a collector, I want seasonal cosmetics to return occasionally.
- As the platform, I want deals to be fair and non-exploitative.

---

## Core Capabilities
- Daily deals
- Weekly bundles
- Seasonal rotations
- Personalized (non-exploitative) deals
- EndlessCoin and EndlessGold pricing
- Deal rarity tiers

---

## Workflows
### Workflow: Deal Rotation
1. Scheduler triggers rotation
2. Deal pool selected
3. Pricing rules applied
4. Deals published to players

### Workflow: Purchase
1. Player selects deal
2. System checks currency
3. Purchase validated
4. Item delivered

---

## Rules & Constraints
- No pay-to-win items
- No loot boxes
- No predatory pricing
- Personalization must be cosmetic-only
- All deals must be reversible and logged

---

## Deep Dive
### Deal Types
- Daily cosmetic deals
- Weekly bundles
- Seasonal exclusives
- Prestige-tier cosmetics
- Vault-boosted deals

### Pricing Rules
- Soft-currency discounts
- Premium-currency bundles

---

## Notes
- All rules, constraints, and workflows are traceable to original planning docs.

---

## Source References
- Migrated and merged from: ENDLESSDEALS_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**