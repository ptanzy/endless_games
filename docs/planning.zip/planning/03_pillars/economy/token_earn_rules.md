# Token Earn Rules System

---

## Purpose
Define the global rules governing how players earn EndlessCoin and EndlessGold across all surfaces—ads, affiliate, gameplay, social, clan, seasonal, and prestige—ensuring fairness, anti-abuse, and long-term economic stability.

---

## Goals
- Provide a unified earn rule system
- Prevent abuse and inflation
- Support all earn surfaces
- Maintain fairness for free players
- Integrate with EndlessVault and EndlessPass

---

## Personas
- **Player:** Wants clear, fair earn rules
- **Free Player:** Relies on earn systems
- **Platform:** Needs stable currency flow

---

## User Stories
- As a player, I want to understand how I earn currency.
- As a free player, I want to earn enough to participate fully.
- As the platform, I want to prevent farming and abuse.

---

## Core Capabilities
- Earn tables
- Daily/weekly caps
- Anti-abuse filters
- Prestige multipliers
- Seasonal multipliers
- Clan bonuses
- Social bonuses

---

## Workflows
### Workflow: Earn Calculation
1. Player completes action
2. System checks earn table
3. Multipliers applied
4. Caps enforced
5. Anti-abuse filters applied
6. Currency delivered

---

## Rules & Constraints
- No unlimited earn loops
- No exploit-friendly actions
- All earn rules must be transparent
- All earn events logged
- No unsafe social interactions

---

## Deep Dive
### Earn Surfaces
- Ads
- Affiliate
- Gameplay
- Social
- Clan
- Seasonal
- Prestige

### Multipliers
- Prestige tier
- Membership
- Seasonal
- Clan
- Social

---

## Notes
- All earn rules, constraints, and workflows are traceable to original planning docs.

---

## Source References
- Migrated and merged from: TOKEN_EARN_RULES_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**