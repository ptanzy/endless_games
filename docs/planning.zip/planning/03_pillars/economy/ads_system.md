
# Ads System

---

## Purpose
Define the deterministic, player-first advertising system that powers EndlessCoin earnings, creator monetization, and brand integrations—while maintaining a safe, zero-moderation environment.

---

## Definitions
- **Rewarded Ad:** Optional ad that grants EndlessCoin or EndlessGold.
- **Auto-Ad:** Non-intrusive ad in media surfaces.
- **Brand Block:** Curated, platform-approved ad segment.
- **Ad Impression:** Logged view of an ad.

---

## Core Concepts
- Ads are always optional and non-intrusive.
- No ads interrupt gameplay or autoplay with sound.
- All ads are brand-safe and reviewed.
- Players and clans may opt in for extra rewards.
- Creators earn ad revenue from eligible content.

---

## Rules
- IF a player opts in, THEN an ad may play and reward is granted.
- IF a creator's content is viewed, THEN ad revenue is shared per platform rules.
- IF a brand submits a campaign, THEN it must be reviewed and approved.
- IF a clan enables ads, THEN EndlessGold is earned for the clan treasury.

---

## Constraints
- MUST NOT interrupt gameplay.
- MUST NOT autoplay with sound.
- MUST NOT appear in unsafe contexts.
- MUST NOT show ads in children’s profiles unless COPPA-compliant.
- MUST NOT use manipulative timers or forced ads.
- MUST review and approve all ads for brand safety.

---

## Workflows
### Rewarded Ad Flow
1. Player opts in.
2. Ad plays.
3. Impression logged.
4. Player receives EndlessCoin.

### Creator Ad Revenue Flow
1. Viewer watches EndlessTube/TV.
2. Ad plays.
3. Creator receives share.

### Brand Block Flow
1. Brand submits campaign.
2. EndlessGames approves.
3. Ads appear in curated blocks.

---

## Edge Cases
- Scenario: Attempted ad in unsafe context → System blocks and logs event.
- Scenario: Attempted ad in child profile without compliance → System blocks and notifies.
- Scenario: Brand campaign flagged as unsafe → System rejects and logs.

---

## System Interfaces
- Interacts with: EndlessTube, EndlessTV, EndlessStream, Profile, Clan, Brand Campaigns, COPPA Compliance, Security, Tools.

---

## Notes
- All ad logic, rules, and constraints are losslessly migrated from ADS_SYSTEM_PLANNING.md and related docs.
- All conflicts resolved per doctrine; all rules are explicit and enforceable.

---

## Source References
- /planning/economy/ADS_SYSTEM_PLANNING.md