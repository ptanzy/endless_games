# Offerwall Technical Requirements

---

## Purpose
Define the enforceable, lossless, and explicit technical requirements for the Offerwall system, as migrated from all planning sources.

---

## Goals
- Ensure deterministic reward attribution
- Support multiple vendors
- Maintain strong fraud prevention
- Provide a unified callback system

---

## Definitions
- **Callback:** A server-to-server notification from a vendor to EndlessGames confirming offer completion.
- **Reward Attribution Engine:** System responsible for crediting users for completed offers.

---

## Core Concepts
- All offerwall integrations must support secure, deterministic, and idempotent reward attribution.
- Multiple vendors are supported via a unified interface and callback system.
- Fraud prevention is enforced at every step of the offerwall process.

---

## Rules
- IF a callback is received, THEN it MUST be HTTPS, signed, timestamped, and include a nonce.
- IF a callback is received from an unapproved IP, THEN it MUST be rejected.
- IF required data fields are missing, THEN the callback MUST be rejected.
- IF duplicate or replayed callbacks are detected, THEN the system MUST prevent double rewards.

---

## Constraints
- MUST only accept callbacks from vendor IP allowlist.
- MUST require all callbacks to be signed and timestamped.
- MUST require the following data fields: User ID, Offer ID, Reward amount, Transaction ID, Timestamp, Signature.
- MUST implement device fingerprinting, IP checks, duplicate prevention, velocity checks, and vendor fraud filters.

---

## Workflows
### Workflow: Callback Handling
1. Vendor sends HTTPS callback with all required fields.
2. System verifies signature, timestamp, nonce, and IP.
3. System checks for duplicates and fraud.
4. Reward Attribution Engine credits user if valid.
5. Analytics events are logged for each step.

### Workflow: Offerwall Embedding
1. Offerwall is embedded via WebView, iframe, or vendor SDK as required.
2. Unified wrapper ensures consistent user experience and data capture.

---

## Edge Cases
- Scenario: Callback missing required field → System rejects and logs error.
- Scenario: Duplicate callback received → System prevents double reward.
- Scenario: Vendor SDK update breaks integration → System triggers technical review and patch.

---

## System Interfaces
- Interacts with: Economy, Security, Analytics, Vendor Management, Reward Attribution Engine.

---

## Notes
- All technical requirements and workflows are traceable to original planning docs and compliance reviews.

---

## Deep Dive
### Reward Attribution Engine
- Deduplication
- Idempotent callbacks
- Creator attribution (future)

### Analytics Events
- Offer viewed
- Offer clicked
- Offer started
- Offer completed
- Reward delivered

---

## Success Criteria
- Zero reward errors
- Low fraud
- High reliability

---

## Source References
- Migrated and merged from: OFFERWALL_TECHNICAL_REQUIREMENTS.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**