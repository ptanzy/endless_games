# Offerwall Selection

---

## Purpose
Define the enforceable, lossless, and explicit rules, constraints, workflows, and definitions for Offerwall selection, as migrated from all planning sources.

---

## Definitions
- **Offerwall:** A platform or service that provides users with offers (such as surveys, app installs, or purchases) in exchange for in-game rewards.
- **Vendor:** A third-party provider of offerwall services.

---

## Core Concepts
- EndlessGames integrates with multiple offerwall vendors to maximize offer diversity, safety, and value.
- Vendor selection is based on quality, safety, inventory breadth, and alignment with platform values.
- Recommended vendors are chosen for their proven track record, safety controls, and inventory quality.

---

## Rules
- IF a vendor is selected for integration, THEN it MUST meet all safety, quality, and compliance criteria.
- IF a vendor is flagged for unsafe or low-quality offers, THEN it MUST be reviewed and may be removed.
- IF a new offerwall category emerges (e.g., new type of offer), THEN the system MUST evaluate and document it before integration.

---

## Constraints
- MUST only integrate with vendors that pass safety and compliance checks.
- MUST maintain a diverse mix of offerwall types (multi-category, mobile install, survey, affiliate).
- MUST NOT integrate vendors with a history of fraud or unsafe content.

---

## Workflows
### Workflow: Vendor Selection
1. Compile full list of available offerwall vendors and products.
2. Evaluate each vendor for safety, offer quality, inventory breadth, and compliance.
3. Select primary, secondary, and backup vendors for each offerwall category.
4. Document reasoning for each selection.
5. Review vendor performance quarterly and update selections as needed.

---

## Edge Cases
- Scenario: Vendor is acquired or changes business model → System re-evaluates and updates selection.
- Scenario: Vendor is flagged for unsafe offers → Immediate review and possible removal.
- Scenario: New offerwall type emerges → System documents and evaluates before integration.

---

## System Interfaces
- Interacts with: Economy, Security, Compliance, Analytics, Vendor Management.

---

## Notes
- All vendor selections and changes are traceable to original planning docs and compliance reviews.

---

## Source References
- Migrated and merged from: OFFERWALL_SELECTION.md, pillar docs, planning critique

---

## Full Vendor List (All Real Offerwall Providers)

### Multi‑Category Offerwalls
- AdGate Media  
- AdGem  
- OfferToro  
- Revenue Universe  
- RevU  

### Mobile Install Offerwalls
- ironSource Offerwall (Unity LevelPlay)  
- Fyber Offerwall Edge  
- Tapjoy Offerwall  

### Survey‑Only Walls
- Prodege  
- Cint  
- Dynata  
- TapResearch  

### Affiliate / Purchase Networks
- Impact.com  
- Awin  
- CJ Affiliate  
- Rakuten Advertising  
- Partnerize  

---

## Recommended Vendor Stack (EndlessGames)

### Primary Offerwalls
- AdGate Media — safest, broadest inventory  
- AdGem — high‑value offers  
- Revenue Universe — strong trials  

### Mobile Install Providers
- ironSource Offerwall — massive inventory  
- Fyber Offerwall Edge — high eCPMs  

### Survey Walls
- Prodege — best quality  
- Cint — huge panel  

### Affiliate Networks
- Impact.com — enterprise brands  
- Awin — global coverage  

---

## Why These Vendors?

### AdGate Media
- Best safety controls  
- Family‑friendly  
- Great for Zero Moderation platforms  

### AdGem
- High‑value offers  
- Strong fraud prevention  

### ironSource
- Industry standard for mobile installs  

### Prodege
- Highest‑quality surveys  

### Impact.com
- Best for brand partnerships  

---

## Success Criteria
- High offer quality  
- Safe for all ages  
- Strong partner mix  
- High player trust  

---

**Migrated and merged content. All conflicts resolved per doctrine.**