# Offerwall Vendor Comparison

---

## Purpose
Provide a full, enforceable, lossless comparison of offerwall vendors, as migrated from all planning sources.

---

## Definitions
- **Vendor:** Third-party provider of offerwall services.

---

## Core Concepts
- Vendor selection is based on safety, offer quality, inventory breadth, compliance, and alignment with platform values.
- Comparison is updated as new data or vendors emerge.

---

## Rules
- IF a vendor fails safety or compliance, THEN it MUST be removed from the recommended stack.
- IF a vendor outperforms others in a category, THEN it MAY be promoted to primary status.

---

## Constraints
- MUST only recommend vendors that meet all safety and compliance requirements.

---

## Vendor Comparison Table

| Vendor                | Category                | Safety Controls | Offer Quality | Inventory Breadth | Fraud Prevention | Notes                       |
|-----------------------|-------------------------|----------------|--------------|-------------------|------------------|-----------------------------|
| AdGate Media          | Multi-Category          | Excellent      | High         | Broad             | Strong           | Family-friendly, safest     |
| AdGem                 | Multi-Category          | Strong         | Very High    | Good              | Strong           | High-value offers           |
| OfferToro             | Multi-Category          | Moderate       | Medium       | Good              | Moderate         |                            |
| Revenue Universe      | Multi-Category          | Good           | High         | Good              | Good             | Strong trial offers         |
| RevU                  | Multi-Category          | Moderate       | Medium       | Good              | Moderate         |                            |
| ironSource Offerwall  | Mobile Install          | Strong         | High         | Massive           | Strong           | Industry standard           |
| Fyber Offerwall Edge  | Mobile Install          | Good           | High         | High              | Good             | High eCPMs                  |
| Tapjoy Offerwall      | Mobile Install          | Moderate       | Medium       | Good              | Moderate         |                            |
| Prodege               | Survey-Only             | Excellent      | Very High    | Large             | Strong           | Highest-quality surveys     |
| Cint                  | Survey-Only             | Good           | High         | Huge              | Good             | Huge panel                  |
| Dynata                | Survey-Only             | Moderate       | Medium       | Good              | Moderate         |                            |
| TapResearch           | Survey-Only             | Moderate       | Medium       | Good              | Moderate         |                            |
| Impact.com            | Affiliate/Purchase      | Excellent      | High         | Enterprise        | Strong           | Best for brand partnerships |
| Awin                  | Affiliate/Purchase      | Good           | High         | Global            | Good             | Global coverage             |
| CJ Affiliate          | Affiliate/Purchase      | Moderate       | Medium       | Good              | Moderate         |                            |
| Rakuten Advertising   | Affiliate/Purchase      | Moderate       | Medium       | Good              | Moderate         |                            |
| Partnerize            | Affiliate/Purchase      | Moderate       | Medium       | Good              | Moderate         |                            |

---

## Notes
- Table is updated as new vendors or data emerge.
- All ratings are based on planning docs, vendor documentation, and compliance reviews.

---

## Source References
- Migrated and merged from: OFFERWALL_VENDOR_COMPARISON_TABLE.md, OFFERWALL_SELECTION.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**