# Token Earn Cap System

---

## Purpose
Define the cap philosophy, tiered earn structure, and anti-abuse protections governing EndlessCoin and EndlessGold earnings across all surfaces. Caps are designed to prevent botting, fraud, and unhealthy farming—not to restrict normal or dedicated players.

---

## Goals
- Protect the economy from abuse and automation
- Ensure caps reflect reasonable human behavior
- Maintain fairness between casual and dedicated players
- Preserve long-term economic stability
- Support healthy play patterns
- Integrate with all earn surfaces (ads, affiliate, gameplay, social, clan, seasonal, prestige)

---

## Personas
- **Player:** Wants to earn freely without feeling restricted
- **Dedicated Player:** Wants to play a lot without hitting walls
- **Platform:** Needs to prevent abuse and maintain stability
- **Economy Designer:** Needs predictable currency flow

---

## Philosophy: Caps Should Reflect Reasonable Behavior
Caps are not meant to limit players—they are meant to limit **unreasonable** behavior.

### Caps should:
- Never hinder normal players
- Rarely affect dedicated players
- Always stop bots, exploiters, and unhealthy farming
- Protect the value of EndlessCoin
- Maintain pacing across seasons and systems

### Caps should NOT:
- Create pressure
- Force daily check-ins
- Punish high engagement
- Feel like "walls"

The goal is **invisible guardrails**, not restrictions.

---

## Cap Types

### Hard Cap
A strict limit. Used only where abuse is extremely likely (ads, affiliate).

### Soft Cap
Earn rate slows down after a threshold. Used for gameplay and clan earn.

### Micro Cap
Very small limit. Used for social earn to prevent spam.

### No Cap
Used for long-term progression (seasonal, prestige).

---

## Tiered Earn Table

| Earn Source         | Cap Type | Daily Cap         | Weekly Cap | Notes                                   |
|---------------------|----------|-------------------|------------|-----------------------------------------|
| Rewarded Ads        | Hard     | 15–20 ads/day     | N/A        | Prevents botting + protects ad networks |
| Offerwall           | Soft     | 4–7 high-value    | 25–40      | Prevents farming + fraud                |
| Affiliate Actions   | Hard     | 5–7/day           | 20–35      | Protects advertisers from abuse         |
| Gameplay Earn       | Soft     | Full rate up to 1000 EC | Soft slowdown after | Never zero; supports healthy play |
| Social Earn         | Micro    | 15–25 actions/day | N/A        | Prevents spam + manipulation            |
| Clan Earn           | Soft     | 150–250 EC/day    | N/A        | Encourages teamwork without farming     |
| Seasonal Earn       | No Cap   | Unlimited         | Unlimited  | Long-term progression; safe             |
| Prestige Earn       | No Cap   | Unlimited         | Unlimited  | Mastery-based; not abusable             |

---

## Notes
- All cap logic, rules, and constraints are traceable to original planning docs.

---

## Source References
- Migrated and merged from: TOKEN_EARN_CAP_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**