# Economy Doctrine

---

## Purpose
Define the enforceable, lossless, and explicit doctrine, rules, and constraints for the platform economy, as migrated from all planning sources.

---

## Core Principles
- **No pay-to-win**
- **All purchases are optional**
- **Player trust > short-term revenue**
- **Cosmetic-only monetization**
- **Predictable, transparent rewards**
- **Controlled inflation**
- **Fair progression pacing**

---

## Currency Types
- **Soft Currency** — Earned through gameplay
- **Premium Currency** — Purchased or rewarded
- **Earned Rewards** — Granted through events, quests, or passes

---

## Sources
- Gameplay
- Events
- Seasonal progression
- Creator experiences
- Purchases

---

## Sinks
- Cosmetics
- Passes
- Upgrades (cosmetic-only)
- Seasonal items
- Creator cosmetics

---

## Constraints
- Inflation must be controlled
- Rewards must scale predictably
- No gameplay advantages may be sold
- Creator monetization must be cosmetic-only
- Seasonal monetization must be time-bound

---

## Anti-Patterns
- Power creep
- Loot boxes
- Unbounded currency generation
- Mandatory purchases

---

## Notes
- All doctrine, rules, and constraints are traceable to original planning docs.

---

## Source References
- Migrated and merged from: ECONOMY_DOCTRINE.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**