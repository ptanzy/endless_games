
# Ad-to-Cash Rewards System

---

## Purpose
Define a safe, deterministic system that allows players to earn a small percentage of real-world cash from ads, redeemable for gift cards, while increasing engagement and retention without introducing moderation, fraud risk, or pay-to-win dynamics.

---

## Definitions
- **Ad-to-Cash Reward:** Small cash value earned from ad engagement.
- **Gift Card Redemption:** Exchange of cash balance for gift card codes.
- **Reward Split:** Percentage of ad reward split between EndlessCoin and cash.

---

## Core Concepts
- 90–95% of ad rewards are EndlessCoin, 5–10% are cash (configurable).
- No direct cash payouts; only gift card redemption.
- No user-generated content or external payment details.
- Membership and leveling perks increase rewards.
- All logic is deterministic and transparent.

---

## Rules
- IF an ad completes, THEN the system MUST apply the configured reward split and deliver both EndlessCoin and cash.
- IF a player reaches the cash-out minimum, THEN the system MUST allow gift card redemption.
- IF a player is a member or has leveling perks, THEN bonuses are applied to both EndlessCoin and cash portions.

---

## Constraints
- MUST NOT allow direct cash payouts (only gift cards).
- MUST NOT collect or store external payment details.
- MUST NOT allow user-generated content in ad-to-cash flows.
- MUST NOT grant cash rewards from disabled ad types.
- MUST be fraud-resistant and not incentivize botting.
- MUST NOT create pay-to-win dynamics.
- MUST remain sustainable at scale.

---

## Workflows
### Ad Impression → Reward Calculation
1. Ad completes.
2. System determines ad type.
3. Apply reward split.
4. Add EndlessCoin to wallet.
5. Add cash to Cash Balance.
6. Apply membership bonuses.
7. Apply leveling perks.
8. Log event for fraud detection.

### Cash-Out Flow
1. Player reaches $10 minimum.
2. Player selects gift card brand.
3. System generates redemption code.
4. Cash Balance decreases.
5. Confirmation logged.

---

## Edge Cases
- Scenario: Attempted cash-out below minimum → System blocks and notifies user.
- Scenario: Attempted fraud or botting → System flags and denies reward.
- Scenario: Disabled ad type → No cash reward granted.

---

## System Interfaces
- Interacts with: EndlessRadio, EndlessTube, EndlessTV, Offerwalls, Membership, Leveling, Security, Tools.

---

## Notes
- All ad-to-cash logic, rules, and constraints are losslessly migrated from AD_TO_CASH_REWARDS_PLANNING.md and related docs.
- All conflicts resolved per doctrine; all rules are explicit and enforceable.

---

## Source References
- /planning/economy/AD_TO_CASH_REWARDS_PLANNING.md