# Preset Communication System

---

## Purpose
Define the unified preset-only communication system used across EndlessGames, enabling expressive, safe, zero-moderation interaction across all social, creator, media, and clan surfaces.

---

## Scope
- Preset comments, reactions, clan chat, statuses, creator interactions
- Creator-authored and seasonal preset packs
- Integration with player expression, clan, and media systems

---

## Dependencies
- /03_pillars/social/player_expression.md
- /02_core_systems/identity/clan_system.md
- /03_pillars/media/media_systems_overview.md

---

## Rules
- IF a player communicates, THEN only preset comments, reactions, or statuses MAY be used.
- IF a player or creator attempts to use open text or unsafe content, THEN the system MUST block and log the attempt.
- IF a new communication feature is added, THEN it MUST comply with preset-only and zero-moderation requirements.

---

## Constraints
- MUST NOT allow open text, user-generated images, or unsafe content in any communication feature.
- MUST ensure all communication features are preset-only and require zero moderation.
- MUST integrate all preset communication features with player expression, clan, and media systems.

---

## Workflows
### Workflow: Sending a Preset Message
1. Player selects preset comment, reaction, or status.
2. System validates and posts the message.
3. Message is visible to relevant audience.
4. Any unsafe or non-preset attempt is blocked and logged.

### Workflow: Creating a Preset Pack
1. Creator submits preset pack for review.
2. System reviews for safety and compliance.
3. Approved pack is made available to players.

---

## Edge Cases
- Scenario: Attempted use of open text or unsafe content → System blocks and logs event.
- Scenario: Integration with a non-compliant system → System rejects and notifies developer.

---

## System Interfaces
- Interacts with: Player Expression, Clan, Media, Creator, Social Graph, Tools.

---

## Source References
- Migrated and merged from: PRESET_COMMUNICATION_SYSTEM_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**