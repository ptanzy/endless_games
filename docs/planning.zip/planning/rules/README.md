# Rules

This directory contains all platform rules. Each rule document must follow this format:

---

## Rule Name

### Description
What the rule enforces.

### Applicability
Where and when the rule applies.

### Enforcement
How the rule is checked and enforced.

---
