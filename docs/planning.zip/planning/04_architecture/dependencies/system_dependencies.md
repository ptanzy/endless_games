# System Dependencies

---

## Purpose
Declare all upstream and downstream dependencies between major systems to avoid ambiguity and circular design. Every system must declare what it depends on and what depends on it. Dependencies must be consistent across all docs.

---

## Dependency Concepts
- **Upstream:** Provides data or capabilities.
- **Downstream:** Consumes data or capabilities.

---

## Core Dependencies
- Identity → Profiles, Clans, Media, Economy, Creator, Brand
- Achievements → Progression → EndlessRank
- Progression → EndlessPass, Events, Quests

---

## Brand & Cosmetics
- Brand Partnerships → Brand Swag Pipeline → Cosmetic System
- Brand Media → Media Systems (Tube, TV, Radio, Stream)

---

## Economy
- Ads / Affiliate / Surveys / Offerwalls → EndlessCoin
- Ad-to-Cash → Gift-card balance
- Clan Ads → Clan Treasury (EndlessGold)
- Membership → Boosts to tokens, XP, and cash share

---

## Social
- Clans → Clan Events → Economy Rewards
- Profiles → Media Surfaces (Tube/TV embeds, Moments, Recaps)

---

## Creator
- Creator Content → Media Systems
- Creator Monetization → Economy
- Brand Ambassador Deals → Brand + Creator + Economy

---

## Tools
- Observability → All services
- Release & Testing → All services

---

## Source References
- Derived from: `PLATFORM_DEPENDENCY_MAP.md`, `CROSS_PILLAR_INTEGRATION.md`, pillar docs

---

**Migrated and merged content. All conflicts resolved per doctrine.**