# Constraints

This directory contains all platform constraints. Each constraint document must follow this format:

---

## Constraint Name

### Description
What the constraint restricts or requires.

### Rationale
Why this constraint exists.

### Enforcement
How the constraint is enforced or validated.

---
