# Project Constitution

## Purpose
This constitution serves as the **Architectural DNA** and the single source of truth for all design decisions, principles, and conventions governing the Endless Games platform. It is binding for all contributors and stakeholders. All subsequent documentation, planning, and implementation must adhere to the rules and standards defined herein to ensure alignment, consistency, and to prevent requirements drift.

---

## 1. Canonical Identification

### 1.1 Milestone Naming Convention
All project milestones must be identified using the following canonical pattern:

**EP-YYYYMMDD-NNN**

- **EP**: Fixed project prefix (Endless Platform)
- **YYYYMMDD**: Date of milestone creation (year, month, day)
- **NNN**: Zero-padded sequence number for the day (e.g., 001, 002, ...)

**Example:**
- EP-20260323-001

This convention must be used in all documentation, tickets, commits, and references to milestones.

---

## 2. Documentation Adherence

- All new and existing documentation must comply with the rules and conventions set forth in this constitution.
- Any deviation or exception must be explicitly approved and documented as an addendum to this file.
- This constitution supersedes all prior conventions and is the authoritative reference for resolving conflicts or ambiguities in design or documentation.

---

## 3. Change Management

- Amendments to this constitution require consensus from the Principal Systems Architect and must be versioned and tracked using the canonical identification scheme.
- All changes must be clearly documented in a dedicated change log section within this file.

---

## 4. Enforcement

- All contributors are responsible for upholding this constitution.
- Reviews, audits, and automated checks should reference this document to ensure compliance and prevent requirements drift.

---

## 5. Canonical Lifecycle Lane System

### 5.1 Overview
All tasks within the Endless Games platform must transition through the following seven distinct lifecycle states, collectively known as the **Canonical Lifecycle Lane**:

1. **planned**: Task is defined and scheduled but not yet claimed.
2. **claimed**: Task has been assigned to a responsible party.
3. **in_progress**: Work on the task has commenced.
4. **for_review**: Task is completed and pending review or approval.
5. **done**: Task has passed review and is formally completed.
6. **blocked**: Task is impeded by an external or internal dependency.
7. **canceled**: Task is formally withdrawn and will not proceed.

### 5.2 Automated Transition Triggers
Transitions between states must be governed by automated triggers to ensure process integrity:

- **planned → claimed**: Triggered when a user or system assigns responsibility for the task.
- **claimed → in_progress**: Triggered when the assignee initiates work (e.g., status update, commit, or time tracking event).
- **in_progress → for_review**: Triggered when the assignee marks the task as ready for review or submits a deliverable.
- **for_review → done**: Triggered by successful review, approval, or automated validation.
- **Any → blocked**: Triggered by detection or declaration of a blocking issue or dependency.
- **blocked → in_progress**: Triggered when the blocking issue is resolved and work resumes.
- **Any → canceled**: Triggered by explicit cancellation action, with mandatory reason logging.

All transitions must be logged and auditable.

### 5.3 API Boundary Tracking and Enforcement
At the API boundary, every task object must expose its current lifecycle state and a complete transition history. The API must:

- Enforce valid state transitions according to the Canonical Lifecycle Lane.
- Reject or flag invalid or out-of-order transitions.
- Emit events for each transition to enable orchestration, monitoring, and policy enforcement.
- Provide endpoints for querying current state, transition history, and reasons for blocked or canceled states.


Automated orchestration policies must reference this lifecycle to ensure compliance and prevent requirements drift.

---

## 6. Infrastructure and Security Guardrails

### 6.1 Environment-Specific API Logic and URL Mapping
All platform APIs and services must distinguish between private enterprise subdomains and public repositories, with explicit logic and URL mapping for each environment:

- **Private Enterprise Subdomains:**
	- APIs must be accessible only within the enterprise network or via authenticated VPN.
	- URL patterns must use enterprise-specific subdomains (e.g., `https://api.enterprise.example.com/...`).
	- Enhanced logging, audit, and compliance checks are mandatory.
	- Data access must be restricted according to enterprise policy.

- **Public Repositories:**
	- APIs must be exposed via public endpoints (e.g., `https://api.public.example.com/...`).
	- Only non-sensitive, sanitized data may be accessible.
	- Rate limiting and abuse prevention must be enforced.
	- Public documentation must clearly indicate environment-specific differences.

All code and documentation must explicitly map and document these differences to prevent environment leakage or misconfiguration.

### 6.2 Data Residency Requirements
- All data storage, processing, and transmission must comply with jurisdictional data residency requirements as defined in the SECURITY_STANDARDS.
- Autonomous agents and services must detect and respect data residency constraints at runtime, ensuring that data does not leave approved regions or storage classes.
- Violations must be logged and trigger automated alerts.

### 6.3 OIDC Token Injection
- All autonomous agents and services must use OpenID Connect (OIDC) tokens for authentication and authorization when interacting with platform APIs.
- OIDC tokens must be injected into all outbound API requests, and token scope must be limited to the minimum required permissions.
- Token handling must comply with platform security standards, including secure storage, rotation, and revocation.
- Automated validation of OIDC token presence and scope is required at the API boundary.

---

## 7. Change Log

- EP-20260323-001: Initial creation of the project constitution.
- EP-20260323-002: Added Canonical Lifecycle Lane system.
- EP-20260323-003: Added Infrastructure and Security Guardrails section.

---

## 6. Change Log

- EP-20260323-001: Initial creation of the project constitution.
- EP-20260323-002: Added Canonical Lifecycle Lane system.
