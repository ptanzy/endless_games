# Permissions Model (RBAC)

---

## Purpose
Define the complete role-based access control (RBAC) model for EndlessGames, covering all user and system roles, capability layers, and access boundaries.

---

## Scope
- Player, creator, clan, seasonal, brand, platform staff, and system actor roles
- Tiered creator and membership-based capabilities
- Explicit permissions for all actions and data access

---

## Player Roles
- **Player:** Consume content, participate in sessions, equip cosmetics, use presets
- **Clan Leader:** Manage clan identity, approve members, configure clan events
- **Clan Officer:** Assist leadership, moderate clan activity
- **Seasonal Participant:** Engage in seasonal progression, unlock seasonal rewards
- **Beta Tester:** Access feature-flagged content

---

## Creator Roles (Tiered)
- **Media Creator:** Upload videos, publish Moments, stream
- **Interactive Creator:** Build interactive content, use Content-Extension SDK
- **Game Creator:** Build games using Game SDK
- **Mode Creator:** Build modes inside EndlessGames titles
- **Creator Partner:** Access brand-approved tools, participate in sponsored events

---

## Platform Roles
- **Platform Staff:** Manage systems, review content, enforce standards
- **System Actor:** Automated or internal system processes with scoped access

---

## Rules
- All permissions must be explicit and documented
- No implicit or inherited permissions without documentation
- All access must be auditable

---

## Dependencies
- /01_standards/global/ownership_enforcement.md
- /00_governance/actor_model/actor_model.md

---

## Source References
- Migrated and merged from: PERMISSIONS_MODEL.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**