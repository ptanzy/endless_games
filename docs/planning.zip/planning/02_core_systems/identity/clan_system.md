# Clan System

---

## Purpose
Define the canonical clan system for EndlessGames, supporting preset-only social groups, shared identity, events, and achievements. Integrates with progression, events, and economy.

---

## Scope
- Preset-only social groups
- Shared EndlessGold treasury
- Clan events and achievements
- Integration with identity, progression, and economy

---

## Dependencies
- /02_core_systems/identity/identity.md
- /03_pillars/social/
- /03_pillars/economy/

---

## Source References
- Migrated and merged from: ACHIEVEMENTS_SYSTEM_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**