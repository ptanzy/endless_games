# Achievements System

---

## Purpose
Define a unified, cross-game achievements system that rewards players for gameplay milestones, platform engagement, creator activity, and seasonal participation. Reinforces long-term progression, identity, and retention without introducing gameplay power or moderation risk.

---

## Scope
- Platform-wide, deterministic milestones
- Game-specific and platform-wide achievements
- Integration with leveling, prestige, quests, events, and profiles
- Zero-moderation, preset-only communication

---

## Dependencies
- /02_core_systems/identity/progression_system.md
- /03_pillars/game/
- /03_pillars/social/

---

## Source References
- Migrated and merged from: ACHIEVEMENTS_SYSTEM_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**