# Progression System

---

## Purpose
Define the unified progression system for EndlessGames, including XP, leveling, perks, and prestige. Provides a multi-year progression arc, meaningful cosmetic-only rewards, and a round-robin perk system that grows evenly across all 100 levels.

---

## Scope
- XP accumulation and curve
- Level thresholds and perks
- Prestige levels and rewards
- Integration with achievements, events, clans, and creator systems
- No gameplay power or pay-to-win

---

## Dependencies
- /02_core_systems/identity/identity.md
- /03_pillars/game/
- /03_pillars/social/

---

## Source References
- Migrated and merged from: PROGRESSION_SYSTEM_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**