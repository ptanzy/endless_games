# SDK Tooling Overview

---

## Purpose
Define the suite of tools that support the EndlessCreator SDK, including validation, editing, packaging, publishing, and debugging workflows.

---

## Tooling Goals
- Safe, performant, compliant SDK content
- Intuitive, powerful creation tools
- Automated validation and packaging
- Rapid iteration and debugging
- Deterministic, observable build outputs

---

## Tool Categories
- Editor Tools: SDK editor, scene/level editor, logic graph editor, asset inspector, template manager
- Validation Tools: asset, logic, safety, performance validators, dependency checker
- Build & Packaging Tools: build pipeline, packaging, versioning, output inspector
- Publishing Tools: publishing console, review submission, error reporting
- Debugging Tools: runtime/debugger, event inspector, log viewer, replay debugger

---


## Rules
- IF a tool is used to create or modify SDK content, THEN it MUST enforce validation, safety, and compliance checks.
- IF a tool publishes or packages content, THEN it MUST log all actions and outputs.
- IF a tool is provided to creators, THEN it MUST NOT expose internal system or platform details.

---

## Constraints
- MUST NOT allow SDK tools to bypass validation, safety, or compliance requirements.
- MUST NOT allow unlogged or unaudited publishing or packaging actions.
- MUST ensure all SDK tool actions are reversible and traceable.

---

## Workflows
### Workflow: SDK Content Validation
1. Creator submits content via SDK tool.
2. Tool runs validation and compliance checks.
3. Content is approved or rejected; result is logged.

### Workflow: SDK Publishing
1. Creator initiates publishing via SDK tool.
2. Tool packages and logs all outputs.
3. Content is published to EndlessHub or relevant platform.

---

## Dependencies
- /06_tools/internal/tools_overview.md
- /02_core_systems/permissions/permissions_model.md

---

## Source References
- Migrated and merged from: SDK_TOOLING_OVERVIEW.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**