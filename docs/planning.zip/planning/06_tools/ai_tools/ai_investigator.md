# AI Investigator Tool

---

## Purpose
Define the internal AI-assisted diagnostic system that analyzes logs, errors, traces, and error signatures to identify issues, test potential fixes in a sandbox environment, and generate Issue Intake items for engineers—without ever modifying production systems.

---

## Rules
- IF AI analyzes logs or errors, THEN it MUST group and classify issues deterministically.
- IF AI tests a fix, THEN it MUST do so in a sandbox environment and log all actions.
- IF AI generates Issue Intake items, THEN it MUST provide full context and never modify production systems.
- IF AI proposes a fix, THEN strict human-in-the-loop review MUST be enforced before any action.

---

## Constraints
- MUST NOT modify production systems or data.
- MUST NOT bypass sandbox validation or human review.
- MUST ensure all AI actions are logged, auditable, and reproducible.

---

## Workflows
### Workflow: Automated Issue Analysis
1. AI ingests logs, errors, and traces.
2. AI groups and classifies issues using error signatures.
3. AI proposes likely causes and generates Issue Intake items.

### Workflow: Sandbox Fix Testing
1. AI replays failure in sandbox environment.
2. AI tests potential fixes and validates results.
3. AI logs all actions and provides results for human review.

---

## Edge Cases
- Scenario: AI proposes unsafe fix → System blocks and notifies engineer.
- Scenario: Sandbox replay fails → AI logs error and requests human intervention.

---

## System Interfaces
- Interacts with: Dev Dashboard, Issue Intake, Sandbox Environment, Logging & Observability, Human Review System.

---

## Source References
- Migrated and merged from: AI_INVESTIGATOR_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**
