# Internal Asset Validator Tool

---

## Purpose
Ensure all assets meet EndlessGames safety, performance, and compliance requirements before publishing, automating validation and reducing manual review workload.

---

## Rules
- IF an asset is uploaded, THEN it MUST be validated for file format, size, resolution, and poly count.
- IF an asset is validated, THEN safety and performance checks MUST be enforced.
- IF an asset fails validation, THEN actionable feedback MUST be provided to the user.

---

## Constraints
- MUST NOT allow unsafe, non-compliant, or unvalidated assets to proceed to publishing.
- MUST NOT bypass safety, performance, or compliance validation.
- MUST ensure all validation actions are logged and auditable.

---

## Workflows
### Workflow: File & Safety Validation
1. User uploads asset.
2. System validates file format, size, resolution, and poly count.
3. System runs safety and performance checks.
4. Asset is approved or rejected with feedback.

---

## Edge Cases
- Scenario: Hidden metadata detected → System rejects and notifies user.
- Scenario: Animation or rig incompatibility → System blocks publishing and logs event.

---

## System Interfaces
- Interacts with: Publishing Pipeline, Audit Log, Asset Management, Feedback System.

---

## Source References
- Migrated and merged from: INTERNAL_ASSET_VALIDATOR_TOOL_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**
