# Tools Overview

---

## Purpose
Define the internal and creator-facing tools that support EndlessGames operations, creation, and governance.

---

## Tool Categories
- Creator Tools: media uploader, content builder, SDK editors, analytics
- Platform Tools: content review, SDK validation, preset management, seasonal config, brand integration
- Operational Tools: monitoring, alerting, deployment, load testing

---


## Rules
- IF a tool is used, THEN it MUST enforce permissions and be auditable.
- IF a tool is developed or deployed, THEN it MUST follow safety doctrine.
- IF a tool is provided to users, THEN it MUST NOT expose internal system details.

---

## Constraints
- MUST NOT allow tools to bypass validation or permissions.
- MUST NOT allow tools to modify authoritative data directly.
- MUST ensure all tool actions are logged and auditable.

---

## Workflows
### Workflow: Tool Usage
1. User requests access to tool.
2. System checks permissions and logs access.
3. User performs allowed actions; all actions are logged.
4. System enforces validation and safety checks on all outputs.

---

## Anti-Patterns
- Bypassing validation
- Implicit permissions
- Modifying authoritative data directly

---

## Dependencies
- /02_core_systems/permissions/permissions_model.md
- /01_standards/global/ownership_enforcement.md

---

## Source References
- Migrated and merged from: TOOLS_OVERVIEW.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**