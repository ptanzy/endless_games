# Clothing Designer Tool

---

## Purpose
Enable internal teams to create tops, bottoms, full outfits, and layered clothing for EndlessGames user models, ensuring fit, safety, and compliance.

---

## Rules
- IF a clothing mesh is imported, THEN it MUST be auto-fit and validated for all user model types.
- IF a texture or material is applied, THEN it MUST use child-safe palettes and pass safety checks.
- IF clothing is published, THEN it MUST pass fit, clipping, and animation validation.

---

## Constraints
- MUST NOT allow unsafe or non-compliant clothing assets.
- MUST NOT bypass fit or safety validation.
- MUST ensure all clothing creation actions are logged and auditable.

---

## Workflows
### Workflow: Mesh Import & Editing
1. User imports clothing mesh.
2. System auto-fits to user model rigs and validates scaling.
3. User adjusts and previews fit.

### Workflow: Texture & Material Application
1. User applies textures, patterns, and palettes.
2. System enforces child-safe palettes and validates materials.

### Workflow: Fit Validation & Publishing
1. System tests fit on all body types and animations.
2. User submits for publishing.
3. System logs and publishes if all checks pass.

---

## Edge Cases
- Scenario: Mesh fails fit validation → System rejects and notifies user.
- Scenario: Unsafe palette detected → System blocks publishing and logs event.

---

## System Interfaces
- Interacts with: Asset Validator, Publishing Pipeline, User Model Rigging Tool, Audit Log.

---

## Source References
- Migrated and merged from: CLOTHING_DESIGNER_TOOL_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**
