# Preset Content Builder Tool

---

## Purpose
Enable internal teams to create safe, preset-only content for EndlessGames, supporting Zero Moderation and preventing unsafe communication channels.

---

## Rules
- IF a preset chat or emote is created, THEN it MUST use only approved phrases, animations, and effects.
- IF an interaction is built, THEN it MUST be preset-only and pass all safety validation.
- IF content is submitted, THEN it MUST NOT contain user-generated text or metadata channels.

---

## Constraints
- MUST NOT allow user-generated text, metadata, or unsafe communication channels.
- MUST NOT bypass preset or safety validation.
- MUST ensure all preset content creation actions are logged and auditable.

---

## Workflows
### Workflow: Preset Chat/Emote Creation
1. User selects approved phrases, animations, or effects.
2. System builds preset menus and previews output.
3. Content is validated and approved for publishing.

### Workflow: Interaction Builder
1. User selects preset NPC behaviors, item interactions, or event triggers.
2. System enforces preset-only and safety rules.
3. Content is validated and approved for publishing.

---

## Edge Cases
- Scenario: Attempt to add user-generated text → System blocks and logs event.
- Scenario: Unsafe emote or interaction detected → System rejects and notifies user.

---

## System Interfaces
- Interacts with: Preset Review Pipeline, Audit Log, Content Publishing Pipeline.

---

## Source References
- Migrated and merged from: PRESET_CONTENT_BUILDER_TOOL_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**
