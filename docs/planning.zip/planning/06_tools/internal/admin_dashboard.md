# Admin Dashboard

---

## Purpose
Provide EndlessGames operational staff with a safe, internal-only dashboard for managing creators, reviewing presets, overseeing events, and handling platform-level administrative workflows—without exposing any engineering or debugging tools.

---

## Core Capabilities
- Preset review and approval
- Creator verification and management
- Event and season scheduling
- Operational oversight
- Strict access control and audit logs

---


## Rules
- IF an admin uses the dashboard, THEN all actions MUST be logged and auditable.
- IF a preset or creator is reviewed, THEN strict access control and safety checks MUST be enforced.

---

## Constraints
- MUST NOT allow admin tools to bypass permissions or validation.
- MUST NOT expose engineering or debugging tools to operational staff.
- MUST ensure all admin actions are logged and reversible.

---

## Workflows
### Workflow: Preset Review
1. Admin selects preset for review.
2. System enforces access control and logs action.
3. Admin approves or rejects preset; result is logged.

### Workflow: Creator Verification
1. Admin selects creator for verification.
2. System enforces access control and logs action.
3. Admin verifies or rejects creator; result is logged.

### Workflow: Event Scheduling
1. Admin schedules event or season.
2. System enforces access control and logs action.
3. Event is scheduled and visible to relevant users.

---

## Dependencies
- /06_tools/internal/tools_overview.md
- /02_core_systems/permissions/permissions_model.md

---

## Source References
- Migrated and merged from: ADMIN_DASHBOARD_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**