# Cosmetic Creation Suite

---

## Purpose
Central tool for creating all cosmetic items in EndlessGames, including clothing, accessories, emotes, and visual effects, with unified workflows and safety enforcement.

---

## Rules
- IF a cosmetic asset is imported, THEN it MUST be validated for safety, poly count, and compatibility.
- IF a category-specific tool is used, THEN it MUST enforce platform safety and compliance rules.
- IF a cosmetic is published, THEN it MUST pass all validation and compliance checks.

---

## Constraints
- MUST NOT allow unsafe, non-compliant, or unvalidated cosmetic assets.
- MUST NOT bypass category-specific or safety validation.
- MUST ensure all cosmetic creation actions are logged and auditable.

---

## Workflows
### Workflow: Asset Import & Validation
1. User imports mesh, texture, material, or animation.
2. System validates asset for safety, poly count, and compatibility.
3. Asset is approved or rejected for further editing.

### Workflow: Category-Specific Creation
1. User selects clothing, accessory, emote, or effect tool.
2. System enforces category-specific rules and previews output.

### Workflow: Publishing
1. User submits cosmetic for publishing.
2. System runs final validation and compliance checks.
3. Cosmetic is published if all checks pass.

---

## Edge Cases
- Scenario: Asset fails validation → System rejects and notifies user.
- Scenario: Unsafe emote or effect detected → System blocks publishing and logs event.

---

## System Interfaces
- Interacts with: Asset Validator, Publishing Pipeline, Audit Log, Category Tools.

---

## Source References
- Migrated and merged from: COSMETIC_CREATION_SUITE_PLANNING.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**
