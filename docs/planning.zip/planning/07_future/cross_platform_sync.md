# Cross-Platform Sync

---

## 🎯 Purpose
Define the future system that synchronizes player progress, cosmetics, media history, and identity across all supported platforms (mobile, desktop, console, TV).

---

## 1. Goals
- Provide seamless cross-device continuity
- Maintain unified identity and progression
- Support media and gameplay sync
- Preserve zero-moderation safety
- Enable future platform expansion

---

## 2. Personas
- Player: Wants to switch devices without losing progress
- Creator: Wants media history synced across devices
- Platform: Needs deterministic, safe sync rules

---

## 3. Core Capabilities
- Cross-platform save sync
- Cosmetic inventory sync
- EndlessPass sync
- EndlessRank sync
- Media history sync
- Clan and social identity sync

---

## 4. Workflows
- Player logs in on any device
- Platform retrieves unified profile
- Local client syncs deltas
- Conflicts resolved deterministically

---


## 5. Rules
- Sync operations must be deterministic and atomic.
- All sync conflicts must be resolved deterministically by the platform.
- Only platform-initiated data is eligible for sync.

## 6. Constraints
- No unsafe user-generated content may be synchronized.
- No cross-platform text or audio is permitted.
- All sync operations must be conflict-safe and auditable.

---

---

## Dependencies
- [Cloud Save Snapshots](./cloud_save_snapshots.md)
- [Identity Core System](../02_core_systems/identity.md)

## Source Reference
- Migrated from: /docs/planning/future/CROSS_PLATFORM_SYNC_PLANNING.md
