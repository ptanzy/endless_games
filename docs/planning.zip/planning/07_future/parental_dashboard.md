# Parental Dashboard

---

## 🎯 Purpose
Define the future parental dashboard that allows parents to view their child’s activity, manage playtime, and understand platform safety—without exposing any unsafe communication or personal data.

---

## 1. Goals
- Provide transparency for parents
- Maintain zero-moderation, zero-text safety
- Support playtime and spending controls
- Reinforce trust in EndlessGames

---

## 2. Personas
- Parent: Wants visibility and control
- Player (Child): Wants safe, fun gameplay
- Platform: Needs to maintain privacy and safety

---

## 3. Core Capabilities
- Playtime overview
- Spending overview
- EndlessPass progress
- Game activity summary
- Safety explanation module
- Optional playtime limits
- Optional spending limits

---

## 4. Workflows
- Parent creates parent account
- Child account linked via code
- Parent dashboard unlocked
- Parent can view activity and set limits

---


## 5. Rules
- Parental dashboards must only display platform-generated activity summaries.
- Playtime and spending controls must be optional and parent-configurable.
- No personal or identifying information may be surfaced to parents.

## 6. Constraints
- No personal messages may be displayed.
- No social interactions or media uploads are shown.
- No identifying information is ever exposed in the dashboard.

---

---

## Dependencies
- [Governance Doctrine](../00_governance/doctrine.md)
- [Data Core System](../02_core_systems/data.md)

## Source Reference
- Migrated from: /docs/planning/future/PARENTAL_DASHBOARD_PLANNING.md
