# Offline Mode

---

## 🎯 Purpose
Define the future offline mode that allows players to enjoy select single-player games without internet access, with deferred sync when reconnected.

---

## 1. Goals
- Provide offline access to single-player games
- Maintain progression integrity
- Support deferred sync
- Preserve zero-moderation safety

---

## 2. Personas
- Player: Wants to play without internet
- Platform: Needs safe offline rules
- Engineer: Needs deterministic sync logic

---

## 3. Core Capabilities
- Offline gameplay
- Local save snapshots
- Deferred sync queue
- Conflict resolution

---

## 4. Workflows
- Player launches offline-compatible game
- Local progress stored in encrypted cache
- When online, client syncs deltas
- Platform validates and merges

---


## 5. Rules
- Only single-player games are eligible for offline mode.
- Offline progress must be securely cached and encrypted.
- Deferred sync must be validated and merged by the platform upon reconnection.

## 6. Constraints
- No media uploads are permitted while offline.
- No social interactions are allowed in offline mode.
- No EndlessCoin or EndlessGold earnings can occur offline.
- Offline XP is limited to safe, predefined thresholds.

---

---

## Dependencies
- [Cloud Save Snapshots](./cloud_save_snapshots.md)
- [Game Pillar](../03_pillars/game/game.md)

## Source Reference
- Migrated from: /docs/planning/future/OFFLINE_MODE_PLANNING.md
