# Global Workflows

---

## Purpose
Document all cross-system, enforceable workflows that govern the operation, integration, and evolution of EndlessGames platform systems.

---

## Workflow: System Migration
1. Identify successor system (if any).
2. Document impact and dependencies.
3. Update PLATFORM_DEPENDENCY_MAP and relevant planning docs.
4. Implement migration logic and communication.
5. Retire old system and mark docs as legacy.

---

## Workflow: Asset & Preset Approval
1. Asset or preset submitted for review.
2. Automated and human checks applied.
3. Approved asset/preset published to platform.
4. Rejected asset/preset returned with reason.

---

## Workflow: Child Account Restriction
1. Parent creates child account.
2. System enforces games-only, no media/social.
3. Parent configures game/time access.
4. System blocks all ineligible features.

---

## Workflow: Content Lifecycle
1. Content authored or recorded.
2. Saved as draft.
3. Submitted for validation.
4. Automated/human validation.
5. Published and discoverable.
6. Appears in Hub/feeds.
7. Engaged by players.
8. Archived or deprecated.

---

## Workflow: Clan Base Update
1. Clan earns achievements or cosmetics.
2. Clan leader applies decorations.
3. Clan Base updates instantly.
4. No unsafe content possible.

---

## Source References
- Derived from: SYSTEM_LIFECYCLE_MANAGEMENT.md, ASSET_VALIDATION.md, CHILD_SAFETY.md, CONTENT_LIFECYCLE.md, CLAN_BASE_PLANNING.md, pillar docs, core docs.

---

**Migrated and merged content. All conflicts resolved per doctrine.**
