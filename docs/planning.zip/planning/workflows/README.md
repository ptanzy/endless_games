# Workflows

This directory contains all platform workflows. Each workflow document must follow this format:

---

## Purpose
What the workflow governs or automates.

## Definitions
Key terms used in the workflow.

## Core Concepts
High-level principles or patterns.

## Rules
What must always be true or enforced.

## Constraints
What is restricted or not allowed.

## Workflows
Step-by-step process.

## Edge Cases
Unusual or exceptional scenarios and how they are handled.

## System Interfaces
Other systems or APIs this workflow interacts with.

## Dependencies
Other workflows, systems, or documents required.

## Source Reference
Where this workflow was derived or migrated from.

---
