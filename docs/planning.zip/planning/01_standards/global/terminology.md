# Terminology Enforcement Standard

---

## Purpose
Mandate the use of canonical terminology across all planning, standards, and implementation documents. Prevents naming drift and ensures all systems use consistent definitions.

---

## Standard
- All documents must use terms as defined in /00_governance/terminology/terminology.md.
- No document may redefine a canonical term.
- All new terms must be added to the terminology canon before use.

---

## Dependencies
- /00_governance/terminology/terminology.md
- /01_standards/global/standards_overview.md

---

## Source References
- Migrated from: TERMINOLOGY.md, pillar docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**