# Ownership Matrix

---

## Purpose
Define explicit ownership for all cross-pillar systems, assets, and workflows. Ensures every system and asset has a single, accountable owner.

---

## Ownership Table

| System/Asset | Owner | Notes |
|---|---|---|
| Identity | Core | Canonical in /02_core_systems/identity/ |
| Profile | Social | References core identity |
| Clan | Social | References core identity |
| Clan Treasury | Economy | References social clan |
| Creator Content | Creator | References core, media |
| Brand Swag | Media | References brand, cosmetics |
| Progression | Core | Canonical in /02_core_systems/identity/ |
| Cosmetics | Media | References core, brand |
| Preset Communication | Social | Canonical in /00_governance/terminology/ |
| Asset Validation | Security | Canonical in /01_standards/security/ |
| Testing | Operations | Canonical in /05_operations/testing/ |
| Tools | Internal Tools | Canonical in /06_tools/internal/ |

---

## Source References
- Derived from: `PLATFORM_OWNERSHIP_MATRIX.md`, pillar docs, core docs, planning critique

---

**Migrated and merged content. All conflicts resolved per doctrine.**