# Global Standards Overview

---

## Purpose
Define the global standards that all EndlessGames systems, pillars, and implementations must follow. These standards enforce doctrine, ensure consistency, and provide a foundation for all domain-specific rules.

---

## Scope
- Applies to all systems, pillars, and implementations
- Enforces doctrine and authority model
- All standards must be referenced in system and pillar docs

---

## Dependencies
- /00_governance/doctrine/platform_doctrine.md
- /00_governance/authority/authority_model.md
- /00_governance/terminology/terminology.md

---

## Source References
- Migrated and merged from: core/standards, pillar docs, planning critique

---

**All content migrated and merged. Conflicts resolved per doctrine.**