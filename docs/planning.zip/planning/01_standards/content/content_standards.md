# Content Standards

---

## Purpose
Define the standards for all content types (games, media, cosmetics, creator content) across EndlessGames. Ensures content is safe, consistent, and aligned with doctrine.

---

## Standard
- All content must be gameplay-only or preset-only where applicable.
- No mature themes or unsafe content.
- Brand and creator content must be reviewed and approved.
- Cosmetics must be visual only, with no gameplay advantage.
- Content must reference canonical definitions and standards.

---

## Dependencies
- /00_governance/doctrine/platform_doctrine.md
- /01_standards/validation/validation_overview.md

---

## Source References
- Migrated from: platform doctrine, pillar docs, content standards

---

**Migrated and merged content. All conflicts resolved per doctrine.**