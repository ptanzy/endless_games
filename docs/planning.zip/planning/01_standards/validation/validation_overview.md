# Validation Standards Overview

---

## Purpose
Define the validation standards for all systems, content, and user interactions across EndlessGames. Ensures all data, assets, and workflows are validated for safety, consistency, and compliance.

---

## Standard
- All user-facing content must be validated before exposure.
- All assets must pass automated and human review.
- Preset-only communication must be enforced.
- No system may bypass validation standards.

---

## Dependencies
- /01_standards/global/standards_overview.md
- /01_standards/security/security_overview.md

---

## Source References
- Migrated from: pillar docs, security docs, core standards

---

**Migrated and merged content. All conflicts resolved per doctrine.**