# AI Policy Standard

---

## Purpose
Define the principles and constraints governing AI usage across EndlessGames, ensuring safety, transparency, and human oversight.

---

## Standard
- AI may be used for content validation, SDK experience validation, media processing, recommendations, safety enforcement, and personalization.
- AI may NOT be used for irreversible decisions without human review, gameplay-affecting decisions, or player punishment.
- AI must be auditable and explainable.
- AI must respect safety constraints and outputs must be validated.
- AI cannot override human moderation.

---

## Responsibilities
- Validation AI: Detect unsafe content, flag violations, enforce preset-only communication.
- Recommendation AI: Rank Hub modules, personalize feeds, suggest creators.
- SDK AI: Validate gameplay safety, detect exploit patterns.

---

## Anti-Patterns
- Black-box decisions
- AI-only moderation
- AI-driven gameplay balance

---

## Dependencies
- /01_standards/global/standards_overview.md
- /00_governance/doctrine/platform_doctrine.md

---

## Source References
- Migrated from: AI_POLICY.md, pillar docs

---

**Migrated and merged content. All conflicts resolved per doctrine.**