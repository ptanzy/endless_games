# Migration Map

---

## Purpose
Map all old planning document paths to their new canonical locations in `/Planning_Version2/`. Includes merged, split, and deprecated files for full traceability.

---

## Migration Table

| Old Path | New Path | Notes |
|---|---|---|
| /planning/PLATFORM_DOCTRINE_OVERVIEW.md | /Planning_Version2/00_governance/doctrine/platform_doctrine.md | Merged, canonicalized |
| /planning/TERMINOLOGY_AND_DEFINITIONS.md | /Planning_Version2/00_governance/terminology/terminology.md | Canonicalized |
| /planning/PLATFORM_DEPENDENCY_MAP.md | /Planning_Version2/04_architecture/dependencies/system_dependencies.md | Canonicalized |
| /planning/ACTOR_DEFINITIONS.md | /Planning_Version2/00_governance/actor_model/actor_model.md | Canonicalized |
| /planning/PLANNING_CRITIQUE.md | /Planning_Version2/00_governance/conflict_resolution/conflicts.md | Merged, conflict log |
| /planning/PLANNING_OVERVIEW.md | /Planning_Version2/00_governance/doctrine/platform_doctrine.md | Merged into doctrine |
| /planning/CROSS_PILLAR_INTEGRATION.md | /Planning_Version2/04_architecture/dependencies/system_dependencies.md | Merged |
| /planning/PLATFORM_OWNERSHIP_MATRIX.md | /Planning_Version2/01_standards/global/ownership_matrix.md | Canonicalized |
| /planning/SYSTEM_LIFECYCLE_MANAGEMENT.md | /Planning_Version2/02_core_systems/lifecycle/lifecycle_management.md | Canonicalized |
| /planning/core/doctrine/ | /Planning_Version2/00_governance/doctrine/ | Merged, canonicalized |
| /planning/core/standards/ | /Planning_Version2/01_standards/ | Canonicalized |
| /planning/core/systems/ | /Planning_Version2/02_core_systems/ | Canonicalized |
| /planning/core/security/ | /Planning_Version2/01_standards/security/ | Canonicalized |
| /planning/social/ | /Planning_Version2/03_pillars/social/ | Canonicalized, pillar-specific only |
| /planning/game/ | /Planning_Version2/03_pillars/game/ | Canonicalized, pillar-specific only |
| /planning/economy/ | /Planning_Version2/03_pillars/economy/ | Canonicalized, pillar-specific only |
| /planning/creator/ | /Planning_Version2/03_pillars/creator/ | Canonicalized, pillar-specific only |
| /planning/media/ | /Planning_Version2/03_pillars/media/ | Canonicalized, pillar-specific only |
| /planning/platform/ | /Planning_Version2/03_pillars/platform/ | Canonicalized, pillar-specific only |
| /planning/tools/ | /Planning_Version2/06_tools/internal/ | Canonicalized |
| /planning/testing/ | /Planning_Version2/05_operations/testing/ | Canonicalized |
| /planning/brand/ | /Planning_Version2/03_pillars/media/ | Merged with media |
| /planning/future/ | /Planning_Version2/07_future/ | Canonicalized |

---

**Merged, split, and deprecated files are fully traceable. All content migrated and conflicts resolved per doctrine.**