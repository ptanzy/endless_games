# Meta

This directory contains meta-level documentation. Each document must follow this format:

---

## Purpose
What the document governs or describes.

## Definitions
Key terms used in the document.

## Core Concepts
High-level principles or patterns.

## Rules
What must always be true or enforced.

## Constraints
What is restricted or not allowed.

## Workflows
Step-by-step process.

## Edge Cases
Unusual or exceptional scenarios and how they are handled.

## System Interfaces
Other systems or APIs this document interacts with.

## Dependencies
Other workflows, systems, or documents required.

## Source Reference
Where this document was derived or migrated from.

---
