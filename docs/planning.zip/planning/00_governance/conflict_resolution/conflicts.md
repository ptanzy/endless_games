# Conflict Resolution Log

---

## Purpose
Document all detected conflicts from the original planning system, record resolution decisions, and provide justifications based on doctrine and the authority model.

---

## Conflict List

### 1. Identity Definition (Core vs Social vs Platform vs Game vs Creator)
- **Conflict:** Multiple definitions and implementations of "identity" across pillars.
- **Resolution:** Canonical definition established in `/02_core_systems/identity/identity.md`. All pillars must reference and extend, not redefine.
- **Justification:** Doctrine mandates a unified identity; core is authoritative.

### 2. Ownership (Doctrine vs Economy vs Data vs Platform)
- **Conflict:** Ownership is defined differently in doctrine, economy, data, and platform docs.
- **Resolution:** Canonical definition in `/02_core_systems/ownership/ownership.md`. All other docs reference this.
- **Justification:** Doctrine and core systems take precedence.

### 3. Preset Communication (Core vs Social vs Tools)
- **Conflict:** "Preset-only" communication is inconsistently defined and referenced.
- **Resolution:** Canonicalized in `/00_governance/terminology/terminology.md` and referenced everywhere.
- **Justification:** Terminology canon is binding.

### 4. Brand Swag Pipeline (Brand vs Media vs Cosmetics)
- **Conflict:** Multiple docs for brand swag and pipeline.
- **Resolution:** Merged into a single pipeline doc in `/03_pillars/media/` and referenced by brand and cosmetics.
- **Justification:** Eliminate duplication, enforce single source.

### 5. Progression System (Leveling, Prestige, Ranking)
- **Conflict:** Multiple docs for progression, leveling, prestige, and ranking.
- **Resolution:** Merged into `/02_core_systems/identity/progression_system.md`.
- **Justification:** Single source of truth for progression.

---

## Precedence Rule
- All conflicts resolved per `/00_governance/authority/authority_model.md`.

---

## Source References
- Derived from: `PLANNING_CRITIQUE.md`, pillar docs, core docs, brand docs, economy docs.

---

**Migrated and merged content. All conflicts resolved per doctrine and authority model.**