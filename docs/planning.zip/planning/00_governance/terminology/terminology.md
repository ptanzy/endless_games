# Terminology Canon

---

## Purpose
Provide a single, canonical source for all key terms used across the EndlessGames platform. This document eliminates naming drift and ensures every term is defined once, with all other documents referencing this source.

---

## Format
- **Term**
- **Definition**
- **Context**
- **Related Terms**

---

## Terms

### Preset-Only
- **Definition:** All player-facing communication uses predefined options only.
- **Context:** Social, communication, moderation, safety.
- **Related Terms:** Preset Pack, Preset Communication.

### Preset Pack
- **Definition:** A purchasable or unlockable set of preset messages, reactions, or statuses.
- **Context:** Social, economy, cosmetics.
- **Related Terms:** Preset-Only.

### Profile
- **Definition:** Hybrid public page + private dashboard for a player.
- **Context:** Social, identity, progression.
- **Related Terms:** Clan, Identity.

### Clan
- **Definition:** Preset-only social group with shared identity and events.
- **Context:** Social, game, economy.
- **Related Terms:** Clan Base, Clan Treasury.

### Clan Base / Clan Hall
- **Definition:** Cosmetic-only shared space for clans.
- **Context:** Social, cosmetics.
- **Related Terms:** Clan, Cosmetics.

### Clan Treasury
- **Definition:** Shared EndlessGold balance earned via clan ads (no cash).
- **Context:** Social, economy.
- **Related Terms:** Clan, EndlessGold.

### Cosmetic
- **Definition:** Any visual or expressive item with zero gameplay impact.
- **Context:** Cosmetics, brand, economy.
- **Related Terms:** Brand Swag, Mini-Swag.

### Brand Swag
- **Definition:** Cosmetics created via brand partnerships or ambassador deals.
- **Context:** Brand, cosmetics.
- **Related Terms:** Cosmetic, Mini-Swag.

### Mini-Swag
- **Definition:** Small accessories ideal for brand collabs.
- **Context:** Brand, cosmetics.
- **Related Terms:** Brand Swag, Cosmetic.

### EndlessCoin
- **Definition:** Earned currency used for most progression and cosmetics.
- **Context:** Economy, progression.
- **Related Terms:** EndlessGold, Ad-to-Cash.

### EndlessGold
- **Definition:** Premium currency used for premium/licensed cosmetics and some perks.
- **Context:** Economy, cosmetics.
- **Related Terms:** EndlessCoin, Clan Treasury.

### Ad-to-Cash
- **Definition:** Small percentage of ad rewards converted to gift-card-style cash.
- **Context:** Economy, rewards.
- **Related Terms:** EndlessCoin, EndlessGold.

---

## Source References
- Derived from: `TERMINOLOGY_AND_DEFINITIONS.md`, all pillar docs, `PLANNING_CRITIQUE.md`

---

**Migrated and merged content. All conflicts resolved per doctrine.**