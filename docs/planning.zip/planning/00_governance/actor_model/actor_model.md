# Actor Model

---

## Purpose
Define all actors who interact with EndlessGames systems, ensuring consistent terminology, responsibilities, and system interactions across the entire platform.

---

## Actor Types

### 1. Player Actors
- **Player:** The primary user of the platform. Engages with games, media, cosmetics, clans, events, and progression systems.
- **Prestige Player:** A long-term player who has reached Level 100 and continues into infinite Prestige for cosmetic mastery.
- **Clan Member:** A player who participates in clan events, clan chat, clan treasury, and clan identity systems.
- **Creator:** A player who uploads gameplay-only media, participates in creator tiers, earns creator rewards, and interacts with brand and monetization systems.
- **Brand Ambassador Player:** A player selected by brands (via platform mediation) to wear brand swag or appear in sponsored playlists.

### 2. Platform Actors
- **Platform:** The EndlessGames system itself. Owns identity, safety, progression, economy, media ingestion, and all enforcement of doctrine.
- **Internal Reviewer:** A platform-authorized reviewer who approves brand swag, preset packs, licensed cosmetics, creator tier upgrades, and brand briefs. No moderation of user content is required due to preset-only and gameplay-only rules.
- **System Administrator:** Internal operator responsible for payouts, analytics, system health, observability, release management, and internal dashboards.

### 3. Brand & Partner Actors
- **Brand Partner:** A company or organization that collaborates with EndlessGames through brand swag, sponsored events, and media partnerships.

---

## Source References
- Derived from: `ACTOR_DEFINITIONS.md`, pillar docs, core docs.

---

**Migrated and merged content. All conflicts resolved per doctrine.**