# Feature: Ads Integration

## Purpose
Display ads in the games view.

## Scope
- Banner or interstitial ads in games page

## Non-Scope
- No rewarded ads
- No ad personalization

## Acceptance Criteria
- Ads are shown in the games view

## Dependencies
- Games view

## Future Hooks
- Advanced ad formats