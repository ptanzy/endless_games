# Feature: Local Single Player

## Purpose
Allow users to play games locally without network or multiplayer.

## Scope
- Launch and play games locally

## Non-Scope
- No multiplayer
- No bots

## Acceptance Criteria
- User can play a game locally

## Dependencies
- Games view

## Future Hooks
- Multiplayer, bots