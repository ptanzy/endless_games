# Feature: User Creation

## Purpose
Allow new users to create an account.

## Scope
- Simple registration form
- Store user credentials locally

## Non-Scope
- No email verification
- No password recovery

## Acceptance Criteria
- User can create an account with username and password
- Error shown for duplicate usernames

## Dependencies
- None

## Future Hooks
- Identity system, email verification