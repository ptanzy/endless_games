# Feature: Games View

## Purpose
Display a list of available games to the user after login.

## Scope
- Games page with list of games
- Dropdown for categories/subcategories
- Overview panel for selected game/category

## Non-Scope
- No multiplayer lobbies
- No game search/filter

## Acceptance Criteria
- User sees games list after login
- Overview panel updates based on selection

## Dependencies
- Login feature

## Future Hooks
- Multiplayer, game search