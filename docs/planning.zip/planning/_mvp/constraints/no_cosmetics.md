# Constraint: No Cosmetics (MVP)

- No cosmetic items, skins, or customization
- No store or cosmetic inventory