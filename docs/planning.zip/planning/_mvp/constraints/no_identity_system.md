# Constraint: No Identity System (MVP)

- No persistent user identity beyond login credentials
- No profiles, avatars, or user icons
- No social or third-party login