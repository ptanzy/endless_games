# Constraint: No Profile (MVP)

- No player profile or stats
- No achievements or progression
- No user history or saved data