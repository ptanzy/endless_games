# Constraint: No Currency (MVP)

- No in-game currency or economy
- No purchases, rewards, or monetization systems