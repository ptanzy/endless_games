# Constraint: No Multiplayer (MVP)

- Only local single-player games
- No online or LAN multiplayer
- No matchmaking or lobbies