# Test Matrix (MVP)

| Feature              | Test Case                        | Manual | Automated |
|----------------------|----------------------------------|--------|-----------|
| Login                | Valid login                      |   X    |           |
| Login                | Invalid login                    |   X    |           |
| User Creation        | New user registration            |   X    |           |
| Games View           | Games list loads                 |   X    |           |
| Games View           | Category dropdown works          |   X    |           |
| Local Single Player  | Game launches and is playable    |   X    |           |
| Ads Integration      | Ads display in games view        |   X    |           |