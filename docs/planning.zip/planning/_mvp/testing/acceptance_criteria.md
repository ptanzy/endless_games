# Acceptance Criteria (MVP)

- User can create an account and log in
- Games page loads and displays available games
- User can launch and play a game locally
- Ads are shown in the games view
- No multiplayer, bots, or progression present