# Manual Testing Plan (MVP)

## Steps
1. Create a new user account
2. Log in with the new account
3. Verify games page loads and lists games
4. Select and launch a game
5. Play the game to completion
6. Verify post-match screen appears
7. Check that ads are displayed on games page
8. Attempt invalid logins and duplicate account creation