# Edge Cases (MVP)

- Attempt to create account with duplicate username
- Attempt to log in with invalid credentials
- Games list is empty
- Game fails to launch
- Ads fail to load