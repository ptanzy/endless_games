# UI Rules (MVP)

- Simple, minimal UI
- Consistent button placement
- Clear navigation between screens
- Responsive layout for desktop and mobile