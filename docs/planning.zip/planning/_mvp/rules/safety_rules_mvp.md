# Safety Rules (MVP)

- No user-generated content
- No chat or messaging
- No external links
- Minimal data collection
- No personal information beyond login credentials