# Performance Rules (MVP)

- Fast load times for games and UI
- Minimal dependencies
- No background network calls
- Optimize for low-end devices