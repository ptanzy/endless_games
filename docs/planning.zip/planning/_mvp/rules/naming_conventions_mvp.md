# Naming Conventions (MVP)

- Use clear, descriptive names for games and UI elements
- Use lowercase_with_underscores for file names
- Use PascalCase for component names