# Workflow: Login Flow (MVP)

## UX Flow
1. User lands on login page
2. User enters credentials
3. System authenticates user
4. On success, user is redirected to Games Page
5. On failure, error message is shown

## System Flow
- POST /login endpoint
- Session created on success