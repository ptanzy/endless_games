# Workflow: Game Launch Flow (MVP)

## UX Flow
1. User selects a game from Games Page
2. User clicks 'Play'
3. Game launches locally

## System Flow
- Game engine loads selected game
- No network or multiplayer logic