# Workflow: Post-Match Flow (MVP)

## UX Flow
1. Game ends
2. Post-match screen appears
3. User sees win/loss or score
4. User can choose 'Play Again' or 'Back to Games'

## System Flow
- Game engine triggers post-match UI
- No stats or progression saved