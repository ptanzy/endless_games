# Backend Endpoints (MVP)

## Overview
Minimal backend endpoints for MVP:

- POST /login
- POST /create-account
- GET /games (list available games)

## Notes
- No multiplayer, stats, or profiles endpoints in MVP.