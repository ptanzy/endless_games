# Client Flow (MVP)

## Overview
Describes the client-side flow for the MVP release.

1. User lands on login/create-account page
2. After login, user is directed to Games Page
3. User selects a game and launches it
4. Game runs locally
5. Post-match screen appears after game ends

## Diagram
// Add diagram here if needed