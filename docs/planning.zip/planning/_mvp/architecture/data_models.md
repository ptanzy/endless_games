# Data Models (MVP)

## User
- username: string
- password: string (hashed)

## Game
- id: string
- name: string
- category: string

## Session
- userId: string
- gameId: string
- score: number