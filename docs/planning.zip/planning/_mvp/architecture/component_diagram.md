# Component Diagram (MVP)

// Insert diagram here

## Components
- Login/Create Account UI
- Games Page UI
- Game Engine (local)
- Ads Display
- Minimal Backend (auth, games list)