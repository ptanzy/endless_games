# Storage Strategy (MVP)

- User credentials stored locally (in-memory or local storage)
- Game data bundled with client
- No cloud or remote storage
- No persistent user data beyond session