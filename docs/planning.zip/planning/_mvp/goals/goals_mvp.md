# MVP Goals

## Purpose
Define the intent and boundaries of the MVP release.

## High-Level Goals
- Deliver a minimal, functional EndlessGames platform.
- Enable user login and account creation.
- Provide access to a small set of local single-player games.

## Success Criteria
- Users can create accounts and log in.
- Games page displays available games.
- Games are playable locally.
- Ads are displayed in the games view.

## Non-Goals
- No multiplayer, bots, or progression systems.
- No player profiles, icons, or cosmetics.

## Release Constraints
- Only local single-player games.
- Minimal UI, no advanced features.

## Release Risks
- Limited engagement due to minimal features.

## Dependencies on Future Releases
- Multiplayer, identity, and progression systems to be added in future releases.