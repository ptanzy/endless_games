# Constraints Summary (MVP)

- Only local single-player games
- Minimal UI
- No advanced features (see non-goals)
- Ads must be integrated in games view
- No external integrations