# Non-Goals for MVP

- No multiplayer support
- No bots or AI opponents
- No player identity or profile
- No progression, achievements, or cosmetics
- No currency or economy systems